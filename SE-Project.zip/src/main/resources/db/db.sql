INSERT INTO user_type(name,description) VALUES ('Admin',"Admin");
INSERT INTO user_type(name,description) VALUES ('Cashier',"Cashier");
