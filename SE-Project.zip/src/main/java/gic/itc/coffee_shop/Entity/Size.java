package gic.itc.coffee_shop.Entity;

public @interface Size {

    int min();

    String message();

}
